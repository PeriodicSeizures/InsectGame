#pragma once

#include "Packet.h"

class OwnedPacket
{
private:
	Packet *packet;
	uint16_t owner_id;

public:
	OwnedPacket(Packet *packet, uint16_t owner_id);
	~OwnedPacket();

	const Packet* getPacket();
	uint16_t getOwnerId();

};

