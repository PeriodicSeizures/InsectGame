#include "OwnedPacket.h"

OwnedPacket::OwnedPacket(Packet* packet, uint16_t owner_id) 
	: packet(packet), owner_id(owner_id) {

}

OwnedPacket::~OwnedPacket() {
	delete packet;
}

const Packet* OwnedPacket::getPacket() {
	return packet;
}

uint16_t OwnedPacket::getOwnerId() {
	return owner_id;
}