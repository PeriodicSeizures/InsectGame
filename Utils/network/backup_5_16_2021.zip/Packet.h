#ifndef PACKET_H
#define PACKET_H

#include <stdint.h>
#include <string>
#include <assert.h>
#include "ByteReader.h"
#include "ByteWriter.h"
#include "../EnumDirection.h"

//#ifdef _DEBUG
//#define _print(packet) (packet)->print()
//#else
//#define _print(packet) {}
//#endif

//template<typename T>

struct Packet {
public:
	enum class Type : uint16_t {
		SRC_CLIENT_CHAT32,		// sent by client to server
		SRC_CLIENT_CHAT64,
		SRC_CLIENT_CHAT128,
		SRC_CLIENT_CHAT256,
		SRC_CLIENT_FIRE,
		SRC_SERVER_PROJECTILE,						// a generic projectile
		SRC_CLIENT_TRUSTED_MOTION,
		SRC_CLIENT_UNTRUSTED_MOTION,
		SRC_SERVER_CONNECTION_REFUSED,	
		SRC_SERVER_CONNECTION_VERSION,	// version of server
		SRC_CLIENT_CONNECTION_LOGIN,	// identity of client
		//count // kind of hacky
	};

	const Type type;
	//const bool special; // if packet is not POD

public:
	Packet(Type type);

	virtual void onReceive(uint16_t user) = 0;

public:
	static void serialize(Packet* in, char* out);

	//static Packet* deserialize(Type type, char* in);

	static Packet* deserialize(Type type, size_t& out_size);

	// what to do when this packet is received by the server
	
};

/* * * * * * * * * * * * * * * * * * * * * * * *

					PACKETS

 * * * * * * * * * * * * * * * * * * * * * * * */

struct PacketChat32 : public Packet {
	PacketChat32();
	char message[32];
	char target[16]; // optional 
	void onReceive(uint16_t user) override;
};

struct PacketChat64 : public Packet {
	PacketChat64();
	char message[64];
	char target[16]; // optional 
	void onReceive(uint16_t user) override;
};

struct PacketChat128 : public Packet {
	PacketChat128();
	char message[128];
	char target[16]; // optional 
	void onReceive(uint16_t user) override;
};

struct PacketChat256 : public Packet {
	PacketChat256();
	char message[256];
	char target[16]; // optional 
	void onReceive(uint16_t user) override;
};

struct PacketConnectionRefused : public Packet {
	PacketConnectionRefused();
	char message[16];
	void onReceive(uint16_t user) override;
};

struct PacketConnectionLogin : public Packet {
	PacketConnectionLogin();
	char username[16];
	char password[16];
	void onReceive(uint16_t user) override;
};

// for clients that are not exploitive (trust)
struct PacketTrustedMotion : public Packet { // client calculates motion (cheaper for server)
	PacketTrustedMotion();
	float x, y;
	float vx, vy;
	Direction dir;
	void onReceive(uint16_t user) override;
};

// for clients that might be exploitive (ignore)
struct PacketUnTrustedMotion : public Packet { // server calculates motion (expensive for server)
	PacketUnTrustedMotion();
	Direction dir;
	void onReceive(uint16_t user) override;
};

#endif