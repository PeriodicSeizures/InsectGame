#include <sstream>
#include "Packet.h"

#include <winsock2.h>

Packet::Packet(Type type) : type(type) { }

void Packet::serialize(Packet* in, char* out) {

	//static_assert(std::is_standard_layout<T>::value, "not a POD type");

	assert(in != nullptr, "in is null");
	assert(out != nullptr, "out is null");

	std::memcpy(out, (void*)in, sizeof(in));
}

// to packet
//Packet* Packet::deserialize(Type type, char *in) {
//
//	Packet *out;
//
//	switch (type) {
//	case Packet::Type::SRC_CLIENT_CHAT32:
//		out = new PacketChat32(); break;
//	case Packet::Type::SRC_CLIENT_CHAT64:
//		out = new PacketChat64(); break;
//	case Packet::Type::SRC_CLIENT_CHAT128:
//		out = new PacketChat128(); break;
//	case Packet::Type::SRC_CLIENT_CHAT256:
//		out = new PacketChat256(); break;
//	case Packet::Type::SRC_SERVER_CONNECTION_REFUSED:
//		out = new PacketConnectionRefused(); break;
//	case Packet::Type::SRC_CLIENT_CONNECTION_LOGIN:
//		out = new PacketConnectionLogin(); break;
//	default:
//		printf("unknown packet received\n");
//		return nullptr;
//	}
//
//	std::memcpy(out, (void*)in, sizeof(in));
//
//	//packet->read(reader);
//
//	return packet;
//}

Packet* Packet::deserialize(Type type, size_t &out_size) {

	switch (type) {
	case Packet::Type::SRC_CLIENT_CHAT32:
		out_size = sizeof(PacketChat32);
		return new PacketChat32();
	case Packet::Type::SRC_CLIENT_CHAT64:
		out_size = sizeof(PacketChat64);
		return new PacketChat64();
	case Packet::Type::SRC_CLIENT_CHAT128:
		out_size = sizeof(PacketChat128);
		return new PacketChat128();
	case Packet::Type::SRC_CLIENT_CHAT256:
		out_size = sizeof(PacketChat256);
		return new PacketChat256();
	case Packet::Type::SRC_SERVER_CONNECTION_REFUSED:
		out_size = sizeof(PacketConnectionRefused);
		return new PacketConnectionRefused();
	case Packet::Type::SRC_CLIENT_CONNECTION_LOGIN:
		out_size = sizeof(PacketConnectionLogin);
		return new PacketConnectionLogin();
	default:
		printf("unknown packet received\n");
		return nullptr;
	}
}