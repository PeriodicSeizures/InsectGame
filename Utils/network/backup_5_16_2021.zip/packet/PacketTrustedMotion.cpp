#include "../Packet.h"

PacketTrustedMotion::PacketTrustedMotion()
	: Packet(Type::SRC_CLIENT_TRUSTED_MOTION) {}

//void PacketTrustedMotion::onReceive(uint16_t user) {
//
//}