#include "../Packet.h"

PacketUnTrustedMotion::PacketUnTrustedMotion()
	: Packet(Type::SRC_CLIENT_UNTRUSTED_MOTION) {}
	
//void PacketUnTrustedMotion::onReceive(uint16_t user) {
//
//}