#include "../Packet.h"

PacketChat64::PacketChat64() 
	: Packet(Type::SRC_CLIENT_CHAT32) {}
	
//void PacketChat64::onReceive(uint16_t user) {
//	
//}