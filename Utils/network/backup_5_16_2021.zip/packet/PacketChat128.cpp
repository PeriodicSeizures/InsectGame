#include "../Packet.h"

PacketChat128::PacketChat128() 
	: Packet(Type::SRC_CLIENT_CHAT32) {}
	
//void PacketChat128::onReceive(uint16_t user) {
//	
//}