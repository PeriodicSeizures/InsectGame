#include "../Packet.h"

PacketConnectionLogin::PacketConnectionLogin()
	: Packet(Type::SRC_CLIENT_CONNECTION_LOGIN) {}

//void PacketConnectionLogin::onReceive(uint16_t user) {
//
//}