#include "../Packet.h"

PacketChat32::PacketChat32() 
	: Packet(Type::CHAT32) {}
	
//void PacketChat32::onReceive(uint16_t user, bool is_server) {}