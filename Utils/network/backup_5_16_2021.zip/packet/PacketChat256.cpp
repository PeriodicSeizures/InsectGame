#include "../Packet.h"

PacketChat256::PacketChat256() 
	: Packet(Type::SRC_CLIENT_CHAT32) {}
	
//void PacketChat256::onReceive(uint16_t user) {
//	
//}